package adminpanel;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class AdminLoginController {

    @FXML
    private AnchorPane
            dashboardContent;

    @FXML
    private AnchorPane usersContent;

    @FXML
    private BorderPane dashboardRoot;

    @FXML
    private AnchorPane adminContent;
    
    @FXML
    private AnchorPane roomsContent;
    
    @FXML
    private AnchorPane reservationContent;
    
    @FXML
    private AnchorPane accountContent;
    
    @FXML
    private AnchorPane settingsContent;
        
    @FXML
    private Button passwordEnterButton;
    
    @FXML
    private Button handleChangePassword;
    
    @FXML
    private PasswordField newPasswordField;
    
    @FXML
    private PasswordField confirmPasswordField;
    
    @FXML
    private CheckBox showPasswordBox;
    
    @FXML
    private TextField visiblePasswordField;
    
    @FXML
    private TextField visiblePasswordField1;
    
    @FXML
    private TextField passwordField;
    
    private String savedPassword = "admin1234";
    
    @FXML
    private Button logoutButton;
    
    @FXML
    private TextField adminPasswordField;
    
    @FXML
    private TextField adminNameField;

    
    
         @FXML
         private void handleLogInClick(ActionEvent event) {
            String inputPassword = adminPasswordField.getText();
            String savedPassword = PasswordManager.getSavedPassword();

             if (inputPassword.equals(savedPassword)) {
        
             try {
             FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
             Parent dashboardRoot = loader.load();

             Stage dashboardStage = new Stage();
             dashboardStage.setScene(new Scene(dashboardRoot));
             dashboardStage.setTitle("Admin Dashboard");
             dashboardStage.show();

            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

            } catch (IOException e) {
            e.printStackTrace();
            }

            } else {
            System.out.println("Incorrect password");
    }
}
}
        