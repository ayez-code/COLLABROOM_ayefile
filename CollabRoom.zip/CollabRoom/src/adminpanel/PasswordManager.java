
package adminpanel;



import java.nio.file.*;
import java.nio.file.Paths;

/**
 *
 * @author ayesh
 */
public class PasswordManager {
    private static final Path PASSWORD_FILE = Paths.get("password.txt");
    private static String savedPassword = loadPassword();
    
    public static String getSavedPassword() {
        return savedPassword;
}
    public static void setSavedPassword(String newPassword) {
        savedPassword = newPassword;
        savePasswordToFile(newPassword);
    }
    
    private static void savePasswordToFile(String password) {
        try {
            Files.write(PASSWORD_FILE, password.getBytes());
        } catch (Exception e) {
            System.out.println("Error saving password: " + e.getMessage());
        }
    }
    
    private static String loadPassword()
    {
        try {
            if (Files.exists(PASSWORD_FILE)) {
                return new String(Files.readAllBytes(PASSWORD_FILE)).trim();
            }
        } catch (Exception e) {
            System.out.println("Error loading password: " + e.getMessage());
        } return "admin1234";
        }
    
    public static boolean checkPassword(String inputPassword) {
        return savedPassword.equals(inputPassword);
    }

    
}

    

