package reservation;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ToggleGroup;

public class FXMLDocumentController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ToggleGroup group1;

    @FXML
    private ChoiceBox<?> myChoiceBox;

    @FXML
    private ChoiceBox<?> myChoiceBox2;

    @FXML
    private ChoiceBox<?> myChoiceBox3;

    @FXML
    void initialize() {
        assert group1 != null : "fx:id=\"group1\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert myChoiceBox != null : "fx:id=\"myChoiceBox\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert myChoiceBox2 != null : "fx:id=\"myChoiceBox2\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert myChoiceBox3 != null : "fx:id=\"myChoiceBox3\" was not injected: check your FXML file 'FXMLDocument.fxml'.";

    }

}
