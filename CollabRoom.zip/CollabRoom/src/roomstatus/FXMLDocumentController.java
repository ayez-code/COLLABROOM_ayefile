package roomstatus;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;

public class FXMLDocumentController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }

}
